# Phase 5 — MySQL Analysis | Food Delivery Operations Analytics

## Dataset inspection

The cleaned dataset used is `food_delivery_eda_cleaned.csv`, with **50,000 rows and 43 exact columns**. The source was not overwritten. The SQL table uses the exact column names, escaped with backticks.


### Exact columns

`order_id`, `customer_id`, `restaurant_id`, `driver_id`, `order_timestamp`, `order_date`, `order_hour`, `day_of_week`, `is_weekend`, `city`, `delivery_area`, `customer_age`, `customer_type`, `restaurant_type`, `restaurant_primary_category`, `restaurant_rating`, `items_count`, `subtotal`, `discount_percent`, `tax_amount`, `service_fee`, `delivery_fee`, `order_total`, `payment_method`, `tip_amount`, `distance_km`, `weather`, `traffic_level`, `delivery_partner_experience_months`, `delivery_partner_rating`, `restaurant_preparation_time_minutes`, `estimated_delivery_time_minutes`, `actual_delivery_time_minutes`, `late_delivery`, `order_status`, `cancellation_reason`, `customer_rating`, `Cancellation_Flag`, `Completed_Flag`, `Delivery_Delay_Minutes`, `Late_Delivery_Flag`, `Distance_Category`, `Hour_Category`


## MySQL environment note

The MySQL 8.0 client is available in the execution environment, but no local MySQL server is running. Therefore, the `.sql` file is fully executable against MySQL 8.0+, while the result tables below are computed from the actual cleaned CSV using equivalent Pandas logic. They are not fabricated values. After importing into MySQL, run the validation queries to confirm the same outputs.

## 5.1 Database and table setup

The SQL file begins with `CREATE DATABASE IF NOT EXISTS food_delivery_db`, `USE food_delivery_db`, and a `CREATE TABLE food_delivery_orders` statement.

### Data type choices

- Identifiers and categories use `VARCHAR`.
- Counts, flags, hours, ages, and experience use integer types.
- Financial amounts use `DECIMAL(10,2)`.
- Ratings use `DECIMAL(3,1)`.
- Distance uses `DECIMAL(6,1)`.
- Timestamps use `DATETIME`; dates use `DATE`.
- Completion-only fields such as actual delivery time, tip, customer rating, and late-delivery flag allow `NULL`.

## 5.2 Data import

Use the `LOAD DATA LOCAL INFILE` statement in the SQL file. If using MySQL Workbench: open a connection with local infile enabled, open the script, confirm the CSV path, run the database/table setup, then run the import statement. The statement skips the header row, parses date/time values, and converts blank nullable fields to `NULL`.

```sql
SELECT COUNT(*) AS total_rows FROM food_delivery_orders;
SELECT * FROM food_delivery_orders LIMIT 10;
```

**Actual CSV result:**

| Check     |   Actual result |
|:----------|----------------:|
| Row count |           50000 |

## 5.3–5.5 SQL fundamentals, validation, and aggregates

The script includes executable examples of `SELECT`, `DISTINCT`, `WHERE`, `ORDER BY`, `LIMIT`, duplicate checks, NULL checks, `COUNT`, `SUM`, `AVG`, `MIN`, and `MAX`. Each query answers a basic project question such as “Which cities exist?”, “Which orders are cancelled?”, or “What is the average order value?”

### Actual validation results

| Check                             |   Actual result |
|:----------------------------------|----------------:|
| Row count                         |           50000 |
| Duplicate order IDs               |               0 |
| Null tip_amount                   |             868 |
| Null actual_delivery_time_minutes |             868 |
| Null late_delivery                |             868 |
| Null cancellation_reason          |           49132 |
| Null customer_rating              |             868 |

### Actual aggregate results

| Metric                         |   Actual result |
|:-------------------------------|----------------:|
| Total Order Value              |     1.90848e+06 |
| Average Order Value            |    38.1695      |
| Average Distance km            |     4.7306      |
| Average Preparation min        |    15.5435      |
| Average Estimated Delivery min |    30.9195      |
| Average Actual Delivery min    |    35.1524      |
| Average Delay min              |     4.2328      |
| Minimum Actual Delivery min    |    10           |
| Maximum Actual Delivery min    |   172           |

## 5.6 KPI analysis

The KPI query calculates status counts and rates from the table rather than hard-coding reference values. `NULLIF` protects rate calculations from division by zero, and completed/non-null delivery outcomes are used for late-delivery metrics.

| Metric               |   Actual result |
|:---------------------|----------------:|
| Total Orders         |      50000      |
| Completed Orders     |      49132      |
| Cancelled Orders     |        868      |
| Completion Rate %    |         98.264  |
| Cancellation Rate %  |          1.736  |
| Late Deliveries      |      17968      |
| Late Delivery Rate % |         36.5709 |

These match the previously calculated Python/Excel references: 50,000 total orders, 49,132 completed, 868 cancelled, 1.736% cancellation rate, 98.264% completion rate, 17,968 late deliveries, and 36.57% late-delivery rate.

## 5.7–5.10 GROUP BY, HAVING, and CASE WHEN

The SQL file groups by city, status, cancellation reason, traffic, weather, customer type, payment method, restaurant type, cuisine, day, and hour. `HAVING` examples use transparent thresholds: cities with more than 200 cancellations, restaurant types with at least 1,000 orders and cancellation rate above 2%, traffic levels above the overall average delivery time, and categories with at least 1,000 orders. `CASE WHEN` reproduces the Python distance bands and creates cancellation/delivery status labels.

## 5.9 Cancellation analysis

### Cancellation reasons

| Cancellation Reason    |   Cancellations |   Share % |
|:-----------------------|----------------:|----------:|
| Driver Unassigned      |             386 |   44.47   |
| Restaurant Unavailable |             160 |   18.4332 |
| Customer Cancelled     |             154 |   17.7419 |
| Changed Mind           |             153 |   17.6267 |
| Long Prep Delay        |              15 |    1.7281 |

### Driver Unassigned by city

| city   |   Driver_Unassigned_Cancellations |
|:-------|----------------------------------:|
| City_A |                               155 |
| City_B |                               118 |
| City_C |                                78 |
| City_D |                                35 |

### City cancellation metrics

| city   |   Orders |   Cancelled_Orders |   Cancellation_Rate_% |
|:-------|---------:|-------------------:|----------------------:|
| City_A |    19888 |                361 |                1.8152 |
| City_B |    14885 |                258 |                1.7333 |
| City_C |    10178 |                172 |                1.6899 |
| City_D |     5049 |                 77 |                1.5251 |

## 5.11–5.17 Delivery, city, traffic, weather, distance, restaurant, customer, and payment analysis

The reusable segment queries in the SQL script calculate order volume, cancellations, cancellation rate, average delivery time, late-delivery rate, order value, preparation time, and supported segment metrics. Important NULL rule: actual delivery analysis excludes cancelled orders because those rows have no delivery outcome.

### City
| city   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:-------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| City_A |    19888 |              19527 |                361 |                 34.9913 |              7341 |               36.7691 |                1.8152 |                37.5941 |
| City_B |    14885 |              14627 |                258 |                 36.0085 |              5586 |               41.0938 |                1.7333 |                38.1896 |
| City_C |    10178 |              10006 |                172 |                 34.0567 |              3314 |               34.1317 |                1.6899 |                33.1201 |
| City_D |     5049 |               4972 |                 77 |                 35.4712 |              1727 |               43.2041 |                1.5251 |                34.7345 |

### Traffic
| traffic_level   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:----------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| High            |    15313 |              14948 |                365 |                 39.8881 |              5778 |               37.8521 |                2.3836 |                38.654  |
| Low             |    15165 |              14987 |                178 |                 30.593  |              5195 |               38.322  |                1.1738 |                34.6634 |
| Medium          |    19522 |              19197 |                325 |                 35.0243 |              6995 |               38.3    |                1.6648 |                36.438  |

### Weather
| weather   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:----------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| Clear     |    28248 |              27857 |                391 |                 33.5558 |              6823 |               38.303  |                1.3842 |                24.4929 |
| Cloudy    |    12810 |              12581 |                229 |                 35.1215 |              4877 |               37.298  |                1.7877 |                38.7648 |
| Rain      |     7627 |               7427 |                200 |                 39.1594 |              5138 |               38.6066 |                2.6223 |                69.18   |
| Storm     |     1315 |               1267 |                 48 |                 47.0726 |              1130 |               41.2556 |                3.6502 |                89.1871 |

### Distance
| Distance_Category   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:--------------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| 0–2 km              |     5333 |               5267 |                 66 |                 22.5943 |              1550 |               37.0104 |                1.2376 |                29.4285 |
| >12 km              |     1254 |               1230 |                 24 |                 76.3179 |               607 |               43.2316 |                1.9139 |                49.3496 |
| >2–5 km             |    27301 |              26818 |                483 |                 30.0723 |              9258 |               37.6976 |                1.7692 |                34.5216 |
| >5–8 km             |    11917 |              11711 |                206 |                 41.1961 |              4711 |               38.2664 |                1.7286 |                40.2271 |
| >8–12 km            |     4195 |               4106 |                 89 |                 54.8717 |              1842 |               40.9253 |                2.1216 |                44.8612 |

### Restaurant type
| restaurant_type   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:------------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| Cafe              |     8140 |               7999 |                141 |                 31.2908 |              2820 |               22.1407 |                1.7322 |                35.2544 |
| Casual Dining     |    13063 |              12848 |                215 |                 38.5993 |              4762 |               52.3218 |                1.6459 |                37.0641 |
| Fast Food         |    27593 |              27106 |                487 |                 34.1104 |              9998 |               33.1726 |                1.7649 |                36.8848 |
| Fine Dining       |     1204 |               1179 |                 25 |                 47.7439 |               388 |              107.507  |                2.0764 |                32.9092 |

### Restaurant category
| restaurant_primary_category   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:------------------------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| Asian                         |     3799 |               3744 |                 55 |                 36.6538 |              1395 |               46.4158 |                1.4477 |                37.2596 |
| Burger                        |    16184 |              15905 |                279 |                 33.9975 |              5687 |               33.9136 |                1.7239 |                35.7561 |
| Dessert                       |     9587 |               9418 |                169 |                 35.4722 |              3470 |               38.8664 |                1.7628 |                36.8443 |
| Healthy                       |     3588 |               3541 |                 47 |                 37.2638 |              1211 |               46.3068 |                1.3099 |                34.1994 |
| Local                         |    12747 |              12498 |                249 |                 35.0377 |              4695 |               37.3156 |                1.9534 |                37.566  |
| Pizza                         |     4095 |               4026 |                 69 |                 36.0693 |              1510 |               41.2358 |                1.685  |                37.5062 |

### Customer type
| customer_type   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:----------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| New             |    10175 |              10008 |                167 |                 35.7277 |              3759 |               40.6795 |                1.6413 |                37.56   |
| Premium         |    14727 |              14452 |                275 |                 34.7106 |              5047 |               33.9654 |                1.8673 |                34.9225 |
| Regular         |    25098 |              24672 |                426 |                 35.1778 |              9162 |               39.6188 |                1.6973 |                37.1352 |

### Payment method
| payment_method   |   Orders |   Completed_Orders |   Cancelled_Orders |   Average_Delivery_Time |   Late_Deliveries |   Average_Order_Value |   Cancellation_Rate_% |   Late_Delivery_Rate_% |
|:-----------------|---------:|-------------------:|-------------------:|------------------------:|------------------:|----------------------:|----------------------:|-----------------------:|
| Cash             |    15050 |              14811 |                239 |                 35.1992 |              5483 |               38.5916 |                1.588  |                37.0198 |
| Credit Card      |    24971 |              24523 |                448 |                 35.1797 |              8970 |               38.059  |                1.7941 |                36.5779 |
| Digital Wallet   |     9979 |               9798 |                181 |                 35.0132 |              3515 |               37.8094 |                1.8138 |                35.8747 |

## 5.18 Subqueries

The script includes subqueries for orders above average order value, cities above the overall cancellation rate, restaurants above average preparation time, and orders above average actual delivery time. A subquery is useful when the comparison value must be calculated from the same table.

## 5.19 CTEs

The script includes CTEs for city cancellation analysis, delivery performance, traffic analysis, and multi-step KPI analysis. A CTE gives a temporary name to an intermediate result, making multi-step SQL easier to read and debug.

## 5.20 Window functions

The script includes `ROW_NUMBER`, `RANK`, `DENSE_RANK`, `SUM() OVER`, `AVG() OVER`, and `PARTITION BY`. Numerical ranking is used only to order a specific metric; it is not an overall “best/worst” judgment.

## 5.21 Advanced SQL query catalog

The final section contains 20 interview-level queries covering: overall cancellation KPI, reason contribution, city cancellation rate, Driver Unassigned by city, high-traffic cancellations, weather, distance, late delivery, city delivery performance, restaurant preparation, customer type, payment method, hour, day, high-value orders, orders above average, cities above overall cancellation rate, delivery time above average, city + traffic, and city + weather.

## 5.22 SQL business insights

1. **Finding:** Driver Unassigned is the largest cancellation reason. **Evidence:** 386 of 868 cancellations (44.47%). **Business meaning:** driver assignment is an important area for investigation. **Possible follow-up:** review assignment timing and city/traffic combinations.

2. **Finding:** Cancellation rates differ by city. **Evidence:** observed city rates range from 1.525% to 1.815%; the highest observed rate is in `City_A` at 1.815%. **Business meaning:** city-level operating conditions warrant comparison. **Possible follow-up:** segment by traffic, weather, and restaurant type.

3. **Finding:** Late delivery is a meaningful completed-order outcome. **Evidence:** 17,968 of 49,132 completed orders are late (36.57%). **Business meaning:** delivery-time reliability is a measurable performance area. **Possible follow-up:** analyze distance, preparation, traffic, and weather jointly.

4. **Finding:** The highest observed traffic cancellation rate is `High` at 2.384%. **Business meaning:** traffic segments can be monitored. **Possible follow-up:** compare traffic mix by city and hour.

5. **Finding:** The highest observed weather cancellation rate is `Storm` at 3.650%. **Business meaning:** weather categories show different observed exposure. **Possible follow-up:** inspect order volume and delivery-time outcomes together.

These are descriptive findings. They do not prove that traffic, weather, city, or driver assignment causes cancellations.

## 5.23 SQL interview preparation


1. **Why did you use GROUP BY?**  
   To summarize orders and rates by business dimensions such as city, traffic, weather, or customer type.

2. **What is the difference between WHERE and HAVING?**  
   WHERE filters rows before grouping; HAVING filters grouped results after aggregation.

3. **COUNT vs COUNT(DISTINCT)?**  
   COUNT counts rows or non-null values; COUNT(DISTINCT) counts unique values, such as unique customers.

4. **How did you calculate cancellation rate?**  
   Cancelled orders divided by total orders, multiplied by 100.

5. **How did you handle NULL values?**  
   I preserved meaningful NULLs and excluded NULL delivery outcomes from delivery-time calculations.

6. **Why use CASE WHEN?**  
   To create readable categories such as distance bands and delivery-performance status.

7. **Why use a CTE?**  
   To name an intermediate result and make multi-step logic clearer.

8. **Why use window functions?**  
   To calculate ranks, running totals, and comparisons without collapsing rows.

9. **How did you calculate late delivery?**  
   I used the source late-delivery flag and restricted the rate to completed orders.

10. **Why exclude cancelled orders from actual delivery analysis?**  
   Cancelled orders have no actual delivery outcome, so including them would distort averages.

11. **What was the largest cancellation reason?**  
   Driver Unassigned, with 386 cancellations.

12. **How did you validate SQL results?**  
   I compared SQL definitions against actual cleaned-data results and the prior Python/Excel references.

13. **How would you optimize a large query?**  
   Filter early, select only needed columns, index status/city/date fields, and inspect the execution plan.

14. **INNER JOIN vs LEFT JOIN?**  
   INNER JOIN keeps matching rows; LEFT JOIN keeps every left-table row and adds matches when available.

15. **When use a subquery?**  
   When a query needs a comparison value or filtered set calculated from another query.

16. **What is PARTITION BY?**  
   It divides rows into groups for a window calculation while keeping row-level detail.

17. **RANK vs ROW_NUMBER?**  
   RANK gives ties the same rank with gaps; ROW_NUMBER gives every row a unique sequence.

18. **How did SQL complement Excel and Python?**  
   Excel supported initial exploration, Python supported reproducible EDA and charts, and SQL supports reusable database analysis.

19. **What business question did SQL answer?**  
   Where do cancellations and delivery delays differ across operational segments?

20. **What would you investigate next?**  
   Assignment timing, preparation, distance, city, traffic, and weather jointly, with more granular operational timestamps.


## Files

- `phase5_food_delivery_analysis.sql` — complete MySQL 8.0+ script.
- `phase5_sql_report.md` — explanations, actual dataset results, business insights, and interview preparation.
- `*_actual_results.csv` — reusable actual result tables.
